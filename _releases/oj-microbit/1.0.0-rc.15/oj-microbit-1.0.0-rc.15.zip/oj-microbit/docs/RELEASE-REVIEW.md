# 정식 출시 점검과 DB 성능 기준

편집 몰입형 화면을 적용한 **1.0.0-rc.15 (2026-11-06)** 기준입니다. 문제 생성은 상단 3단계, 학생 풀이는 넓은 MakeCode와 접이식 실행 결과를 사용합니다. 접기는 실행을 멈추거나 다시 시작하지 않습니다. [적용·검증 범위](EDITING-FOCUS-1.0.0-rc.15.md)를 확인하세요.

갱신일: 2026-11-06. 현재 대상은 **1.0.0-rc.15 + OJ Platform 2.5.9 / Addon API 1.9 이상**입니다. 최신 ZIP을 먼저 설치한 뒤 기존 설치 명령을 다시 실행하면 현재 ZIP의 실행기 버전으로 업데이트합니다. 새 버전 폴더·이미지를 준비한 뒤 **릴리스·oj-live/1·GPIO 채점·실제 PXT 컴파일**을 검사하고 마지막에 WordPress 연결을 확정합니다. 실패 시 이전 설정과 서비스 상태를 복원하고 이전 포트·인증키로 health를 확인합니다. HUSTOJ Docker·컨테이너·볼륨·네트워크·DB를 관리하는 명령을 추가하지 않았습니다. [업데이트·복구 점검](INSTALLER-AUDIT-1.0.0-rc.14.md)을 확인합니다. 상태 유지 실행과 DB 스키마·저장 쿼리는 유지합니다. 실제 Ubuntu/systemd/Docker·WordPress·HUSTOJ 병행 부하는 별도 검수입니다. 아래 이전 버전 기록은 해당 버전의 검증입니다.

0.4.0의 자동 설치·Node 24.22.1, 0.4.1의 키 환경 상속 보완에 이어 0.4.2는 기존 Docker 경로의 APT·서비스 변경 차단, 포트 소유권·디스크 사전 검사를 추가했습니다. DB 스키마 2·채점 계약 `oj-gpio/3`은 유지합니다. 자동 검사 근거는 `VALIDATION.md`, 설치 조건은 `INSTALLER.md`, 공존 범위는 `HUSTOJ-COEXISTENCE.md`를 확인합니다. 아래 실제 WordPress/MySQL·Docker·실물 USB 승인은 여전히 남아 있습니다. 우선순위·완료 기준을 포함한 새 기능과 오류 점검 계획은 [RELEASE-PLAN.md](RELEASE-PLAN.md)에 정리했습니다.

0.5.0은 공개 전 점검·필드 오류·운영 오류 분류·학급 배포를 구현하고 스키마 3을 추가했습니다. 기존 요약/개인정보 정책에 학급 관계의 원자 저장·작은 배치 삭제를 확장했습니다. 새 학급 인덱스 UNION 전체의 MySQL 계획, schema 1/2→3, 실제 Context 권한과 동시 저장·삭제 잠금을 P0 승인에 추가합니다. 상세 사용법은 [P1-FEATURES.md](P1-FEATURES.md), 실제 로컬 근거는 `VALIDATION.md`를 확인합니다.

현재 판정은 **개선된 출시 후보**입니다. 로컬 자동 검사와 실제 MakeCode/PXT 흐름은 검증했지만, 운영 WordPress/MySQL·Docker·물리 USB의 출시 승인은 아래 현장 검증을 완료한 뒤 내립니다. 데이터량·통계·서버 자원·동시 요청에 관계없이 느려지지 않는다는 보장은 하지 않습니다.


## rc.4 실제 메뉴·화면 추가 점검

두 ZIP 설치 순서, 기본 문제 유형 필터, 수업별 적용·결과 링크와 실제 역할 권한, 원래 요청 경로를 바꾸지 않는 메뉴 선택, WordPress 하위 경로 주소 생성·전송을 확인합니다. 외부 유형만 선택할 때 기존 프로그램 집계는 실행하지 않고, 정확한 수업 한 페이지는 현재 권한과 일괄 메타데이터만 조회합니다. 표준 메뉴를 이용할 수 없는 전용 권한 교사는 대체 관리 메뉴를 사용하며 일반 문제 수정 권한은 얻지 않습니다. 수행 모드에서 새 수업 상세/결과 링크를 제한하며 기존 마이크로비트 직접 페이지의 정책은 별도 현장 검증 범위입니다. 실제 WordPress 테마·MySQL·서버 부하·USB 승인은 P0로 남아 있습니다.

## rc.3 추가 점검

공개 문제는 수업 밖 사용자도 일반 풀이를 할 수 있어야 합니다. 수업 적용은 공개 범위 변경과 별개이며, 배정 ID를 서버에서 확인해 일반/다른 수업 기록을 섞지 않습니다. 명단 한 페이지와 일괄 최근 결과로 미제출 학생까지 표시하고 전체 제출 COUNT/GROUP BY·학생별 추가 조회를 사용하지 않습니다. 원본 작성자라도 수업 관리 권한 없이는 그 수업 결과를 볼 수 없습니다. 공개 중단·회수는 새 작업을 막고 과거 기록의 배정 식별자를 보존합니다. 실제 SQL/원자 저장/권한 회수·부하는 현장 P0입니다. 공개 문제는 site_recent의 21개(최대 51개) 메타데이터만 조회합니다. 새 수업 목록은 활성 소속 100개의 수업별 후보를 먼저 제한해 기본 최대 2,100개·상한 5,100개의 키를 원본 상태와 결합하며 원본 공개 중단이 많아도 끝까지 재검색하지 않습니다. 일반/수업 이력은 scope_recent(assignment_id,exercise_id,id)와 scope_records(assignment_id,exercise_id,user_id,id)를 사용합니다. 수업 결과는 현재 명단 20명(최대 50명)의 최신 요약만 IN 절로 일괄 조회합니다. 구 배포의 기존 상한은 별도로 유지합니다.

## rc.2 당시 점검

그룹과 수업 ID 충돌·관리자/교사/학생 권한·불완전 소속 조회·실행 중 권한 회수·수업→그룹 전환 CAS·관계 rollback·archive·개인정보 삭제를 검사합니다. UI는 설명/풀이/임시 저장/연습/제출/내역을 구분하고 미저장 이동·링크 복원·교사 미리보기를 확인합니다. 그룹+수업 양쪽 인덱스 UNION의 실제 MySQL 계획과 병행 부하는 여전히 현장 승인 항목입니다. 그룹·수업 각각 최대 100개 소속일 때 사이트 분기를 포함한 201개 분기에서 기본 4,221개·최대 10,251개의 작은 후보 키만 읽습니다. 최종 목록은 21개(최대 51개)이며 관계는 한 번의 일괄 조회로 최대 2,551행을 확인합니다. 한 사용자의 플랫폼 소속 원장 조회 비용은 이 전용 저장소 상한과 별개이므로 실제 플랫폼 자료량으로 측정합니다.

## 발견한 문제와 반영한 개선

| 우선순위 | 확인한 문제 | 반영한 조치 |
|---|---|---|
| P1 | 이력 목록에서 사용하지 않는 큰 result_json과 trace를 최대 100건 읽고 해석 | 상태·점수·통과 여부 컬럼만 조회. 원문은 권한을 확인한 한 건의 상세 요청에서만 읽음 |
| P1 | 최신 100건 이후 자료 접근 불가, 필터와 정렬에 맞지 않는 복합 인덱스 | 기본 20건·최대 50건 커서 페이지. `id < beforeId`와 필터 순서에 맞춘 인덱스. 전체 개수 집계 생략 |
| P1 | 기간 정리가 인덱스 없는 전체 삭제로 긴 잠금 유발 가능 | 기간 인덱스로 테이블별 최대 50개 키 선택 후 기간 재확인 삭제, 남은 작업은 다음 요청에서 처리 |
| P1 | 개인정보 내보내기가 큰 원문 50건씩 읽고, 사용자 삭제는 전량 삭제 | 키 페이지를 먼저 정한 후 테이블당 원문 한 건만 내보냄. 삭제는 테이블당 최대 100개 키로 제한 |
| P1 | 한 번에 수천 개의 재생 타이머와 로그 DOM 생성 | 재생 타이머 한 개, 장치 상태 단위 갱신, 표시 로그 상한, 닫힌 표는 펼칠 때 생성 |
| P1 | WordPress가 개발용 test-process 실행기도 준비됨으로 수용 | health와 실행 응답 모두 docker-no-network 요구, 누락·개발 모드는 거부 |
| P1 | API 프로세스가 종료되면 작업 제한이 부모에만 의존 | 작업 이미지 내부 독립 40초 제한, 로컬 이미지 전용 --pull=never |
| P2 | 상태 요청마다 Docker 이미지 확인 프로세스 생성 | 진행 중 조회 공유, 성공·실패를 5초 캐시 |

프로젝트 저장·채점 후 권한 확인도 작은 과제 메타데이터로 처리합니다. 학생 소스·비공개 조건·점수 의미와 `oj-gpio/3` 채점 계약은 유지합니다.

## DB 조회와 인덱스

| 경로 | 전용 DB 조회 원칙 | 대응 인덱스 |
|---|---|---|
| 교사 과제 목록 | owner_id·archived 동등 필터, id 범위·내림차순, LIMIT 21 | owner_recent(owner_id,archived,id) |
| 학생 공개 과제 | status·archived 동등 필터, id 범위·내림차순 | published_recent(status,archived,id) |
| 관리자 전체 목록 | archived 동등 필터, id 범위·내림차순 | active_recent(archived,id) |
| 교사 채점 이력 | exercise_id 동등 필터, id 범위·내림차순, JSON 제외 | exercise_recent(exercise_id,id) |
| 학생 본인 이력 | exercise_id·user_id 동등 필터, id 범위·내림차순 | exercise_records(exercise_id,user_id,id) |
| 단건 프로젝트 | exercise_id·user_id 동등 조회 | 복합 기본 키 |
| 만료 정리 | created_at / updated_at / window_start 범위와 작은 키 목록 | attempt_expiry / project_expiry / limit_expiry |
| 구기록 요약 전환 | result_status 빈 값에서 최대 8개 ID, 원문은 한 건씩 해석 | summary_queue(result_status,id) |

목록마다 `COUNT(*)`를 실행하지 않고 한 건을 더 조회해 다음 페이지 유무를 판단합니다. 이력 목록의 전용 쿼리 수는 행 수에 따라 증가하지 않습니다. 단건 상세는 권한 메타데이터 확인과 한 건의 원문 조회로 제한합니다. 새 자료의 요약값은 저장할 때 같이 기록합니다. 구자료는 전체 backfill을 하지 않으며, 전환 전에는 요약 준비 중으로 표시하고 원문 상세를 보존합니다.

개인정보 내보내기는 WordPress가 page 번호를 전달하는 계약의 예외입니다. 깊은 페이지도 작은 인덱스 키만 건너뛴 후 원문 한 건을 읽습니다. 건너뛰는 키 수 자체는 페이지가 깊어질수록 늘어납니다. 이 방식을 대화형 목록으로 확대하지 않습니다. 매우 큰 내보내기는 여전히 여러 요청이 필요합니다. [WordPress 내보내기 계약](https://developer.wordpress.org/plugins/privacy/adding-the-personal-data-exporter-to-your-plugin/)과 [삭제 계약](https://developer.wordpress.org/plugins/privacy/adding-the-personal-data-eraser-to-your-plugin/)에 따라 완료 전에는 done을 반환하지 않습니다.

계정 삭제 중 남은 ID는 limits의 예약된 erase: 키로 보존합니다. cron 이벤트가 비활성화 중 소모돼도 다음 유지보수가 삭제를 재개합니다. quota 만료와 구별해 완료 전에 지우지 않습니다. 이 재시도는 WP-Cron이 실제로 실행되어야 진행되므로 중앙 서버 준비의 cron 설정을 유지합니다. [이벤트 중복 방지와 인자 일치](https://developer.wordpress.org/reference/functions/wp_schedule_single_event/)도 적용합니다.

## 정식 출시 전에 반드시 닫아야 할 항목

| 우선순위 | 현장 시험 | 승인 근거 |
|---|---|---|
| P0 | 운영과 같은 MySQL/MariaDB에서 v1/2→v3 업그레이드·백업 복구 | 기존 과제·프로젝트·구 채점 원문 보존, 필수 컬럼/학급 관계·인덱스와 schema_version=3·InnoDB 확인 |
| P0 | 실제 DB 실행계획과 대량 자료 부하 | 10만·100만 이력과 사용자 편중 자료에서 첫/중간/마지막 커서 조회. 인덱스 범위·실제 읽은 행 수·정렬·p50/p95·PHP 최대 메모리 기록 |
| P0 | 실제 WordPress 인증·권한·저장 충돌 | 교사 간 접근, 학생 타인·학급 밖 이력, 비공개 조건, 공개·학급 권한 회수 중 실행, CAS 충돌, 개인정보 삭제/저장 잠금·완료까지 시험 |
| P0 | 실제 Docker 작업·실패·강제 종료 | 단순 GPIO canary를 실제 /v1/run으로 실행. OOM·무한 루프·API 강제 재시작 후 40초 제한과 잔여 컨테이너 확인. --network=none·read-only·비루트·cap drop 확인 |
| P0 | 실제 교실 동시 접속 | 예상 수업 규모로 편집·미리보기·채점 병행. 동시 작업 2개와 429 재시도 안내·요청 시간 제한·서버 회복 확인 |
| P0 | V1/V2 실물 업로드 | HTTPS Chrome/Edge에서 HEX·USB·장치 취소·케이블 분리·재연결·실제 서보/I²C 배선 확인 |

성능 합격선은 운영 자원에 맞춰 확정합니다. 초안 목표는 목록 SQL p95 100ms 이하, 목록 API p95 500ms 이하이며, 이는 현재 측정된 운영 수치가 아닙니다. 더 중요한 조건은 행 수가 늘어도 목록의 JSON 읽기·조회 수·응답 크기가 같이 늘어나지 않는 것입니다. 인덱스가 있다는 사실만으로 정렬 제거·성능을 단정하지 않고 [MySQL ORDER BY와 EXPLAIN 지침](https://dev.mysql.com/doc/refman/8.4/en/order-by-optimization.html)에 따라 실제 계획을 확인합니다.

운영 DB에서는 실제 접두사와 존재하는 소유자·과제·중간 커서 값으로 다음 SELECT의 계획을 확인합니다. `EXPLAIN ANALYZE`가 지원되는 DB에서는 별도의 시험 환경에서 같은 SELECT의 실제 실행 시간도 측정합니다.

```sql
EXPLAIN SELECT id,owner_id,title,status,revision,updated_at
FROM wp_oj_microbit_exercises
WHERE owner_id=10 AND archived=0 AND id<50000
ORDER BY id DESC LIMIT 21;

EXPLAIN SELECT id,exercise_id,exercise_revision,user_id,result_status,result_passed,result_score,created_at
FROM wp_oj_microbit_attempts
WHERE exercise_id=10 AND id<500000
ORDER BY id DESC LIMIT 21;
```

스키마의 컬럼·인덱스 추가는 큰 테이블에서 잠금·I/O를 유발할 수 있습니다. 자료 백업과 점검 모드에서 업그레이드하고, 학생 트래픽을 다시 열기 전에 완료를 확인합니다. 기존에 생성된 구 인덱스는 dbDelta가 자동 제거하지 않을 수 있으므로 실제 쿼리와 계획을 대조한 뒤 별도 유지보수에서 중복 인덱스를 정리합니다. 무조건 인덱스를 늘리는 방식은 쓰기 비용을 키우므로 피합니다. [MySQL 인덱스 비용 지침](https://dev.mysql.com/doc/refman/8.4/en/optimization-indexes.html)

## 다음 개선 제안

1. 0.5.0에 구현한 요청 ID·오류 코드·소요 시간·종료 코드 로그가 실제 PHP-FPM/systemd에서도 전달되는지 확인합니다. 소스·토큰·비공개 입력이 없는 상태를 운영 설정에서도 유지합니다.
2. 학급 부하 측정 후 실행기 동시성·대기열·역압 정책을 정합니다. 현재 준비 상태는 이미지 존재를 확인하며, 실제 컴파일·실행을 인증하는 canary를 대신하지 않습니다.
3. 반복 컴파일 비용이 병목으로 확인되면 고정 런타임+정규화 프로젝트 해시 기반의 크기 제한 캐시를 설계합니다. 검증 전 임의 결과 캐시를 성적으로 재사용하지 않습니다.
4. 실제 DB의 느린 쿼리·읽은 행 수·정리 지연·구요약 전환 잔량을 관측하고, 기록 보관 기간과 배치 크기를 조정합니다.

이후 DB 변경 규칙은 플러그인 루트의 `AGENTS.md`에 고정했습니다. 검사 근거와 설치 후 확인 범위는 `VALIDATION.md`를 함께 확인합니다.
